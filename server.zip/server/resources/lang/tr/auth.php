<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Kimlik Doğrulama
    |--------------------------------------------------------------------------
    |
    | Aşağıdaki metinler kimlik doğrulama (giriş) sırasında kullanıcılara
    | gösterilebilecek mesajlardır. Bu metinleri uygulamanızın
    | gereksinimlerine göre düzenlemekte özgürsünüz.
    |
    */

    'failed' => 'Введенные пользовательские данные не совпадают с данными в системе.',
    'throttle' => 'Вы предприняли слишком много попыток входа в систему. Пожалуйста, мы попробуем еще раз через несколько секунд.',
];
