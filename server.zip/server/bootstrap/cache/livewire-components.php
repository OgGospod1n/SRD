<?php return array (
  'breadcrumb' => 'App\\Http\\Livewire\\Breadcrumb',
  'dashboard' => 'App\\Http\\Livewire\\Dashboard',
  'document.create' => 'App\\Http\\Livewire\\Document\\Create',
  'document.edit' => 'App\\Http\\Livewire\\Document\\Edit',
  'document.share' => 'App\\Http\\Livewire\\Document\\Share',
  'document.show' => 'App\\Http\\Livewire\\Document\\Show',
  'search' => 'App\\Http\\Livewire\\Search',
);