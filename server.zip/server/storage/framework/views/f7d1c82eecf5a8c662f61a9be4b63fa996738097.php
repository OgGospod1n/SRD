<a href="/">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 3800 4800" class="w-16 h-16 float-left">
        <g><path fill="#3980FB" d="M0 4800h3800V840L2960 0H0"/><path fill="#9EC2FF" d="M2960 840h840L2960 0"/><path fill="#1F53B1" d="M3800 1680V840h-840"/></g>
        <g><path fill="#FFF" d="M900 1976h2000v-212H900m0 670h2000v-211H900m0 670h2000v-212H900m0 635h1200v-176H900"/></g>
    </svg>
    <h1 class="float-left" style="font-weight: 700; font-size: 32px; margin-left: 15px; margin-top: 10px;">Совместные документы</h1>
</a>
<?php /**PATH C:\collaborative-document-editor-development\server\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>