<?php echo e($slot); ?>

<?php /**PATH C:\collaborative-document-editor-development\server\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>